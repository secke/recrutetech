# RecruteTech — Benchmarking & Plan d'action

Livrable produit suite à l'analyse concurrentielle (Mercor, HireVue, Crosschq, HackerRank, CodeSignal, Karat, Sapia.ai) et à l'identification des pain points 2026 du marché du recrutement IA tech.

## 📂 Structure du livrable

```
recrutetech-benchmark/
├── 00-BENCHMARKING-REPORT.md          ← Rapport principal (à lire en premier)
├── README.md                           ← Ce fichier
└── skills/                             ← 10 skills à intégrer
    ├── cv-adaptive-personalization/SKILL.md       (P0)
    ├── live-coding-evaluator/SKILL.md             (P0)
    ├── anti-cheating-integrity-layer/SKILL.md     (P0)
    ├── transparent-scoring-explainability/SKILL.md (P0)
    ├── candidate-practice-mode/SKILL.md           (P0)
    ├── structured-rubric-builder/SKILL.md         (P0)
    ├── fairness-bias-audit/SKILL.md               (P1)
    ├── accessibility-accommodations/SKILL.md      (P1)
    ├── ats-integration-hub/SKILL.md               (P1)
    └── identity-verification-deepfake-defense/SKILL.md (P1)
```

## 🚦 Ordre de lecture recommandé

1. **`00-BENCHMARKING-REPORT.md`** — Synthèse exécutive, cartographie concurrentielle, tableau Impact × Faisabilité, et roadmap en 2 vagues.
2. **Skills P0** (vague 1, 6-8 semaines) — Cœur du différenciateur produit.
3. **Skills P1** (vague 2, 8-12 semaines) — Conformité légale + expansion marché B2B.

## 🎯 Les 3 angles de game-winning

D'après l'analyse, RecruteTech peut devenir game-winner sur 3 axes que les concurrents ne couvrent pas ensemble :

1. **Profondeur conversationnelle adaptive** — Aria + CV personnalisé bat Mercor sur la naturalité.
2. **Integrity layer non-invasif** — face à Cluely et consorts (79 % des fraudes 2026), notre angle "questions de défense conversationnelles" surpasse le proctoring brutal de HireVue.
3. **Transparence radicale** — explicabilité de bout en bout + audit de biais publié = inverse de la boîte noire HireVue, argument marketing puissant.

## ✅ Critères de succès globaux

Une fois les 6 skills P0 livrés, RecruteTech doit pouvoir afficher publiquement :

- *« Le seul recruteur IA qui vous explique pourquoi »* (transparent-scoring + practice-mode)
- *« Conçu avec les communautés sourdes, neurodivergentes et francophones africaines »* (accessibility + fairness-audit)
- *« Détecte 85 %+ des tentatives de triche IA sans surveillance invasive »* (anti-cheating-integrity-layer)
- *« 4 connecteurs ATS natifs en 90 jours »* (ats-integration-hub)

## 📅 Roadmap consolidée

| Semaine | Livrable |
|---|---|
| S1-S2 | `cv-adaptive-personalization` + `structured-rubric-builder` |
| S3-S4 | `transparent-scoring-explainability` + `candidate-practice-mode` |
| S5-S6 | `live-coding-evaluator` (Python uniquement, MVP) |
| S7-S8 | `anti-cheating-integrity-layer` (Phase 1 — defense questions) |
| S9-S10 | `fairness-bias-audit` (Phase 1 — synthétique) |
| S11-S12 | `accessibility-accommodations` (modes essentiels) |
| S13-S14 | `ats-integration-hub` (Greenhouse + Lever + webhook) |
| S15-S16 | `live-coding-evaluator` Phase 2 (JS/TS/Go) + `anti-cheating` Phase 2 |
| S17-S20 | `ats-integration-hub` (Teamtailor, Recruitee, Ashby) |
| S21-S24 | `identity-verification-deepfake-defense` (MVP) |

## 📚 Sources

L'analyse repose sur 40+ sources publiques (G2, Capterra, Glassdoor, ToolsForHumans, jobright.ai, eesel AI, plaintes ACLU/EPIC, étude Fabric "19 368 entretiens", rapports HireVue Candidate Experience, blog HackerRank/CodeSignal, HR Dive, The Conversation, Medium, Reddit). Toutes citables sur demande pour audit.
